﻿Param (
    [Parameter(Mandatory=$false)]
    [string] $logFilePath = "Default",
    [switch] $On = $false,
    [switch] $Off = $false,
    [switch] $QueryConfig = $false
    )
    
    function AddDebugToConfig ([string] $configFile, [string] $logFilePath, [string] $AgentLogFileName) 
    {
        $config = [xml](Get-Content $configFile)
        $systemDiagnostics = $config.configuration["system.diagnostics"]

        if(!$systemDiagnostics)
        {
            $systemNet =  $config.CreateElement("system.diagnostics")
            $config.configuration.AppendChild($systemNet)
            $systemDiagnostics = $config.configuration["system.diagnostics"]
        }

        if(!$systemDiagnostics["trace"])
        {
            $trace = $config.CreateElement("trace")
            $systemDiagnostics.AppendChild($trace)
        }
        
         $systemDiagnostics["trace"].SetAttribute("autoflush", $True)
         $systemDiagnostics["trace"].SetAttribute("indentsize", 4)

        if(!$systemDiagnostics["trace"]["listeners"])
        {
            $listeners = $config.CreateElement("listeners")
            $systemDiagnostics["trace"].AppendChild($listeners)
        }

        if(!$systemDiagnostics["trace"]["listeners"]["add"])
        {
            $add = $config.CreateElement("add")
            $systemDiagnostics["trace"]["listeners"].AppendChild($add)
        }

                   
         $systemDiagnostics["trace"]["listeners"]["add"].SetAttribute("name", "textWriterListener")
         $systemDiagnostics["trace"]["listeners"]["add"].SetAttribute("type", "System.Diagnostics.TextWriterTraceListener")
        

         $systemDiagnostics["trace"]["listeners"]["add"].SetAttribute("initializeData", $logFilePath+$AgentLogFileName)

        if(!$systemDiagnostics["trace"]["listeners"]["remove"])
        {
            $remove = $config.CreateElement("remove")
            $systemDiagnostics["trace"]["listeners"].AppendChild($remove)
        }

        $systemDiagnostics["trace"]["listeners"]["remove"].SetAttribute("name", "Default")
           
        $config.Save($configFile)

        Write-Host ("")
        Write-Host -ForegroundColor:Green ("The log is stored: "+$logFilePath+$AgentLogFileName +". Restarting the service.")
        Write-Host ("")

    }

    function RemoveDebugFromConfig ([string] $configFile) 
    {
        $config = [xml](Get-Content $configFile)
        $systemDiagnostics = $config.configuration["system.diagnostics"]

        if($systemDiagnostics)
        {
            $config.configuration.RemoveChild($systemDiagnostics)
            $config.Save($configFile)

            Write-Host ("")
            Write-Host -ForegroundColor:Green ("Debug logging is turned off. Restarting the service.")
            Write-Host ("")
        }
             
    }

    function QueryCurrentConfig ([string] $configFile, [string] $AgentServiceName) 
    {
        $config = [xml](Get-Content $configFile)
        $systemDiagnostics = $config.configuration["system.diagnostics"]

        if(!$systemDiagnostics)
        {
            Write-Host ("")
            Write-Host -ForegroundColor:Green ("Debug logging is turned off.")
            Write-Host ("")
        }
        elseif (!$systemDiagnostics["trace"]["listeners"]["add"])
         {
            Write-Host ("")
            Write-Host -ForegroundColor:Green ("The configuration file seems to be corrupt. Please run the script with the -Off parameter.")
            Write-Host ("")
         }
        else 
         {

            Write-Host ("")
            Write-Host -ForegroundColor:Green ("The connector debug logging is configured. Parameters:")
            Write-Host ("")
            Write-Host ("name: " + $systemDiagnostics["trace"]["listeners"]["add"].GetAttribute("name"))
            Write-Host ("type: " + $systemDiagnostics["trace"]["listeners"]["add"].GetAttribute("type"))
            Write-Host ("initializeData: " + $systemDiagnostics["trace"]["listeners"]["add"].GetAttribute("initializeData"))
            Write-Host ("")


            $tempPathFile=$systemDiagnostics["trace"]["listeners"]["add"].GetAttribute("initializeData")
            
            
            if ($tempPathFile -ne $null)
              {  
                if ((Test-Path $tempPathFile) -eq $False)    
                 {
                   Write-Host ("")
                   Write-Host -ForegroundColor:Red "The debug log does not exist."
                   Write-Host ("")
                 }
                else
                 {
                   Write-Host ("")
                   Write-Host -ForegroundColor:Green "The debug log exist."
                   Write-Host ("")
                 }
              }              

            $connectorService = Get-Service -Name $AgentServiceName

            if($connectorService.Status -ne "Running")
             {
               Write-Host ("")
               Write-Host -ForegroundColor:Red "The $AgentServiceName Service is not running."
               Write-Host ("")
             }
        
            if($connectorService.Status -eq "Running")
             {
               Write-Host ("")
               Write-Host -ForegroundColor:Green "The $AgentServiceName Service is running."
               Write-Host ("")
             }
         }
   }

   function VerifyACLonPath([string] $logFilePath)
    {
    
     $objSID = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-20")
     $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
     
     $aclFolder = Get-Acl $logFilePath 
     
     If ($aclFolder -ne $null) 
      {
     
        $tempFileSystemRights= " "
        $tempInheritanceFlags= " "        

        foreach ($item in $aclFolder.Access)
         {
          if (($item.AccessControlType -eq "Allow") -and ($item.IdentityReference -eq $objUser.value))
           {
             $tempFileSystemRights= $tempFileSystemRights + $item.FileSystemRights
             $tempInheritanceFlags= $tempInheritanceFlags + $item.InheritanceFlags        
           }
         }

         If (($tempFileSystemRights.IndexOf("FullControl") -gt -1) -or (($tempFileSystemRights.IndexOf("Read") -gt -1) -and ($tempFileSystemRights.IndexOf("Write") -gt -1)))
              {
                if ($tempInheritanceFlags.IndexOf("ObjectInherit") -gt -1) {Return $True}
              }
       }    
      Return $False  
    }

   function Information([String] $AgentServiceName, [string] $logFilePath, [string] $AgentLogFileName) 
    {
        Write-Host ("")
        Write-Host ("This script can be used to activate / deactivate debug logging for the $AgentServiceName service.")
        Write-Host ("")
        Write-Host ("Use the switch -On to turn on the debug logging.")
        Write-Host ("Use the switch -Off to turn off the debug logging.")
        Write-Host ("Use the parameter -logFilePath to specify a directory other than the default. (example: -logFilePath C:\MSLOG\)")
        Write-Host ("Use the parameter -QueryConfig to see the current debug configuration.")
        Write-Host ("")
        Write-Host ("By default the log is stored: "+$logFilePath+$AgentLogFileName)
        Write-Host ("")
        Write-Host -ForegroundColor:Yellow ("Before you activate the debug logging with a non-default logFilePath, please ensure the following:")
        Write-Host ("")
        Write-Host ("The log folder does exists.")
        Write-Host ("The Network Service account has at least read & write permission in the folder.")
        Write-Host ("")
        Write-Host -ForegroundColor:Red ("Please note that the script with parameters -On/-Off restarts the $AgentServiceName service.")
        Write-Host ("")            
    }
     
    function RestartService ([string] $AgentServiceName)
    {
     Restart-Service -Name $AgentServiceName
    
     $connectorService = Get-Service -Name $AgentServiceName
    
     if($connectorService.Status -ne "Running")
      {
        Write-Host ("")
        Write-Host -ForegroundColor:Red "The $AgentServiceName Service did not start properly. Please restart the Service"
        Write-Host ("")
      }
        
     if($connectorService.Status -eq "Running")
      {
        Write-Host ("")
        Write-Host -ForegroundColor:Green "The operation has been completed successfully. The $AgentServiceName Service is running."
        Write-Host ("")
      }
    }

    Clear-Host

   if ((Test-Path ".\AgentConstants.ps1") -eq $False)    
    {
     Write-Host ("")
     Write-Host -ForegroundColor:Red "File not found: AgentConstants.ps1."
     Write-Host ("")
    }
    else
    {
     . .\AgentConstants.ps1
    
   
     if ($logFilePath -eq "Default") {$logFilePath=$Env:ALLUSERSPROFILE+"\Microsoft\"+$AgentDefaultLogFolder}

     if ($logFilePath[$logFilePath.length-1] -ne "\") {$logFilePath=$logFilePath+"\"}

     if ($QueryConfig -eq $True)
      {
       QueryCurrentConfig $AgentConfigFile $AgentServiceName

       Information $AgentServiceName $logFilePath $AgentLogFileName
      }
     else
      {
       if (($On -eq $False -and $Off -eq $False) -or ($On -eq $True -and $Off -eq $True)) 
        {
         Information $AgentServiceName $logFilePath $AgentLogFileName
        }
       elseif ($On -eq $True) 
        {
         if ((Test-Path $logFilePath -PathType Container) -eq $True)    
         {
          if (( VerifyACLonPath $logFilePath) -eq $True)    
             {
             AddDebugToConfig $AgentConfigFile $logFilePath $AgentLogFileName
             RestartService $AgentServiceName
             }
          else    
             {
               Write-Host ("")
               Write-Host -ForegroundColor:Red "The NETWORK SERVICE has no appropriate permissions on the log folder $logFilePath . Please fix it and try it again."
               Write-Host -ForegroundColor:White "Please note: The script checks only explicit rights assignement. Rights based on group membership are not checked."
               Write-Host ("")
               Information $AgentServiceName $logFilePath $AgentLogFileName
             }  
         }
         else
         {
          Write-Host ("")
          Write-Host -ForegroundColor:Red "The log folder " $logFilePath  " does not exist."
          Write-Host ("")
          
          $logFilePath=$Env:ALLUSERSPROFILE+"\Microsoft\"+$AgentDefaultLogFolder
          
          Information $AgentServiceName $logFilePath $AgentLogFileName
          }
         }
        else
         {
         RemoveDebugFromConfig $AgentConfigFile
         RestartService $AgentServiceName
         }
        } 
       }   