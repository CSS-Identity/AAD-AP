$AgentConfigFile = "C:\Program Files\Microsoft AAD App Proxy Connector\ApplicationProxyConnectorService.exe.config"
$AgentDefaultLogFolder = "Microsoft AAD Application Proxy Connector"
$AgentServiceName = "Microsoft AAD Application Proxy Connector"
$AgentLogFileName = "AzureADApplicationProxyConnectorTrace.log"